#include <bits/stdc++.h>

using namespace std;
int solve(vector<int>& nums, int i, int prev) {
        if(i >= nums.size()) return 0;
        int take = 0, not_take = solve(nums, i + 1, prev);
        if(nums[i] > prev) take = 1 + solve(nums, i + 1, nums[i]);
        return max(take,  not_take );
    }


int main() {
    vector<int> nums = {4,19,1,2,5,7};
  
    int length = solve(nums,0,-1);
    cout << "Length of Longest Increasing Subsequence " << length <<endl;
    return 0;
}
