#include <bits/stdc++.h>
using namespace std;

int solve(vector<int>& nums) {
        int n = nums.size();
        vector<int> dp(n , 1);
        int max_ans=0;
        for(int i=0 ; i<n ; i++){
            for(int prev = 0 ; prev<i ; prev++){
                if(nums[prev] < nums[i]){
                    dp[i] = max(dp[i] , 1+dp[prev]);
                }
            }
            max_ans = max(max_ans , dp[i]);
        }
        return max_ans;
		
        }


int main() {
    vector<int> nums = {4,19,1,2,5,7};
  
    int length = solve(nums);
    cout << "Length of Longest Increasing Subsequence " << length <<endl;
    return 0;
}
