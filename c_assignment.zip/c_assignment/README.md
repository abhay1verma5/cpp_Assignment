MY first approach is using recursive soln 
Time Complexity: O(2^n)
Space Complexity: O(n)


2nd Approach is using dynamic programming  because in recusive soln many subproblems are solved multiple times, leading to exponential time complexity

Time Complexity: O(n^2)
Space Complexity: O(n^2)


3rd Approach is Tabulation using bottom-up approach  reducing Space time  complexity

Time Complexity: O(n^2)
Space Complexity: O(n)


